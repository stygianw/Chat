﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading;
using System.Collections.Specialized;
using MvcApplication14.Models;
using System.Collections;


namespace MvcApplication14.Helpers
{
    public static class DatabaseHelper
    {
        
        private static int AddedMessagesCounter { get; set; }
        public static Queue<Message> MessagesInMemory { get; private set; }
        
        static DatabaseHelper()
        {
            MessagesInMemory = new Queue<Message>();
        }

        public static void LoadContentToMemory() 
        {
            if (MessagesInMemory.Count == 0)
            {
                using (ChatContext ctx = new ChatContext())
                {
                        var lst = ctx.Messages.Count() < 1000 ? ctx.Messages.Include("RelatedUser").ToList() : ctx.Messages.Include("RelatedUser").Take(1000).ToList();
                        foreach (var item in lst)
                        {
                            MessagesInMemory.Enqueue(item);
                        }
                    
                }    
            }
            
        }

        public static void StartDumpingToDatabase(object cancellationToken)
        {
            
            while (true)
            {
                if (((CancellationToken)cancellationToken).IsCancellationRequested)
                {
                    return;
                }

                if (AddedMessagesCounter == 0)
                {
                    Thread.Sleep(15000);
                    continue;
                }

                using (ChatContext ctx = new ChatContext())
                {
                    

                    for (int i = MessagesInMemory.Count - 1; i >= (MessagesInMemory.Count - AddedMessagesCounter); i--)
                    {
                        string usn = MessagesInMemory.ElementAt(i).RelatedUser.UserLogin;
                        MessagesInMemory.ElementAt(i).RelatedUser = ctx.Users.FirstOrDefault(m => m.UserLogin == usn);
                        ctx.Messages.Add(MessagesInMemory.ElementAt(i));
                    }
                    
                    ctx.SaveChanges();
                
                }
                
                AddedMessagesCounter = 0;
                Thread.Sleep(15000);
            }
        }

        public static void AddMessage(string username, string message)
        {

            Message ms = new Message();
            ms.RelatedUser = new User();
            ms.RelatedUser.UserLogin = username;
            ms.Text = message;
            MessagesInMemory.Enqueue(ms);
            
            if (MessagesInMemory.Count > 1000)
            {
                MessagesInMemory.Dequeue();    
            }

            ActiveListHelper.StampTime(username);
           
            AddedMessagesCounter++;
        }
     
        
    }

}